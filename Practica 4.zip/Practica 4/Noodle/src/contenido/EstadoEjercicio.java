package contenido;

/**
 * Enum Estado Ejercicio
 * @author Jose Ignacio Gomez
 * @author Oscar Gomez
 * @date 28/03/2017
 */
public enum EstadoEjercicio {
	ESPERA, ABIERTO, RESPONDIDO, TERMINADO;
}
